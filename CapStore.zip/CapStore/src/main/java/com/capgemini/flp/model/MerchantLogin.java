package com.capgemini.flp.model;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class MerchantLogin {
	@Id
	private String emailId;	

	private String password;
	
	
	public MerchantLogin() {
		// TODO Auto-generated constructor stub
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	public MerchantLogin(String emailId, String password) {
		super();
		this.emailId = emailId;
		this.password = password;
		
	}

	
	
	
	
}
